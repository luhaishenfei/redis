package com.lsgf.generateincrno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenerateIncrNoApplication {

    public static void main(String[] args) {
        SpringApplication.run(GenerateIncrNoApplication.class, args);
    }

}
